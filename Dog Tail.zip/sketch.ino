#include <ESP32Servo.h>

Servo myservo;
const int tp =33;
const int ep =32;
const int led=25;
void setup() {
  // put your setup code here, to run once:
  myservo.attach(18);
  Serial.begin(9600);
  pinMode(tp, OUTPUT); //trig pin
  pinMode(ep, INPUT);//echo pin
  pinMode(25, OUTPUT);
  pinMode(26, INPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
  long duration,cm;
  bool s;
  digitalWrite(tp, LOW);
  delayMicroseconds(1);
   digitalWrite(tp, HIGH);
  delayMicroseconds(1);
   digitalWrite(tp, LOW);

   duration=pulseIn(ep,HIGH);
  cm=duration/58;
  Serial.print(cm);
  if(digitalRead(26)==HIGH)
  {
    myservo.write(90);
    delay(3000);
    return;
  }
//Serial.println(digitalRead(26));
int k;
  delay(10); // this speeds up the simulation
  int i=0;
  if(cm>=50)
  k=20;
  else 
  k=5;
  
if(cm<=10)
{
  digitalWrite(led,HIGH);
}
else
{
while(i<=180)
{digitalWrite(led,LOW);
  myservo.write(i);
  delay(k);
  i++;
}
for (i = 180; i >= 0; i -= 1) { 
    myservo.write(i);              
    delay(k);                       
  }
}
}
